﻿

namespace Web.Api.Core.Interfaces
{
    public interface IUseCaseRequest<out TUseCaseResponse> { }
}
