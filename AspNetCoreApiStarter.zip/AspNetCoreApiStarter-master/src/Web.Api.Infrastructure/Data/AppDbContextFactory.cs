﻿using Microsoft.EntityFrameworkCore;
using Web.Api.Infrastructure.Shared;


namespace Web.Api.Infrastructure.Data
{
    public class AppDbContextFactory : DesignTimeDbContextFactoryBase<AppDbContext>
    {
        protected override AppDbContext CreateNewInstance(DbContextOptions<AppDbContext> options)
        {
            return new AppDbContext(options);
        }
    }
}
