﻿using Microsoft.EntityFrameworkCore;
using Web.Api.Infrastructure.Shared;

namespace Web.Api.Infrastructure.Identity
{
    public class AppIdentityDbContextFactory : DesignTimeDbContextFactoryBase<AppIdentityDbContext>
    {
        protected override AppIdentityDbContext CreateNewInstance(DbContextOptions<AppIdentityDbContext> options)
        {
            return new AppIdentityDbContext(options);
        }
    }
}
